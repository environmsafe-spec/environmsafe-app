EnvironmSafe audit pack
Company: EnvironmSafe For Engineering, Trading, and Services Ltd
Period: 2026-01-01 to 2026-11-07
Created: 2026-11-07T22:52:15.869Z

Amounts in USD unless a currency column says otherwise.
files/ holds each attachment named <document number>/<file name>; attachments.csv gives its SHA-256 so you can check it was not altered.
